# Jociel 💜

Um aplicativo web interativo sobre saúde sexual que apresenta curiosidades aos usuários de forma envolvente.

![Jociel 💜 Screenshot]()

## 📋 Sobre o Projeto

Jociel 💜.

### Funcionalidades

- Exibição de curiosidades sobre saúde sexual
- Interface interativa com botões "Revelar" e "Próxima"
- Design responsivo para desktop e dispositivos móveis
- Animações e efeitos visuais para melhor engajamento

## Desenvolvido com 💜 por Jociel 

